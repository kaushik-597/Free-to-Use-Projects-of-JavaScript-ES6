# Quiz App 🎯

A simple yet fun **Quiz Application** built with **HTML, CSS, and
JavaScript**.\
The app displays multiple-choice questions, allows users to pick an
answer, and shows the final score at the end.

## Features ✨

-   Start, Next, and Restart functionality\
-   Multiple-choice questions\
-   Prevents selecting more than one choice per question\
-   Score display at the end\
-   High Score system (stored in browser using localStorage) --- shown
    only after completing the quiz\
-   Responsive design with clean UI

## Project Structure 📂

    quiz-app/
    │── index.html        # Main HTML file
    │── style.css         # CSS styling
    │── script.js         # Core JavaScript logic
    │── README.md         # Project documentation

## How to Run 🚀

1.  Download or clone this repository.\
2.  Extract the `.zip` file (if downloaded).\
3.  Open `index.html` in any modern web browser.\
4.  Play the quiz and test your knowledge!

## Technologies Used 🛠

-   **HTML5**
-   **CSS3**
-   **Vanilla JavaScript (ES6)**

## Future Improvements 🔮

-   Add timer-based questions\
-   Add categories/difficulty levels\
-   Store multiple high scores with player names

## License 📜

This project is **free to use** and open for learning purposes.
