document.addEventListener("DOMContentLoaded", () => {
  const quesBox = document.querySelector("#question-container");
  const displayQues = document.querySelector("#question-text");
  const displayChoices = document.querySelector("#choices-list");
  const nextBtn = document.querySelector("#next-btn");
  const resultBox = document.querySelector("#result-container");
  const displayScore = document.querySelector("#score");
  const restrtBtn = document.querySelector("#restart-btn");
  const strtBtn = document.querySelector("#start-btn");
  const displayHighScore = document.querySelector("#highscore");
  const questions = [
    {
      question:
        "What is the name of the sword that Zoro received from Kuina's family?",
      choices: ["Enma", "Sandai Kitetsu", "Wado Ichimonji", "Shusui"],
      answer: "Wado Ichimonji",
    },
    {
      question:
        "Who was the first character to mention the 'Will of D' in the series?",
      choices: [
        "Gol D. Roger",
        "Silvers Rayleigh",
        "Dr. Kureha",
        "Jaguar D. Saul",
      ],
      answer: "Dr. Kureha",
    },
    {
      question:
        "What did Blackbeard say was the reason he could eat two Devil Fruits?",
      choices: [
        "His unique body structure",
        "He trained with Whitebeard",
        "The Yami Yami no Mi allows it",
        "He stole Whitebeard’s power",
      ],
      answer: "His unique body structure",
    },
    {
      question:
        "What is the name of the poneglyph that tells the location of the Ancient Weapons?",
      choices: [
        "Rio Poneglyph",
        "Road Poneglyph",
        "Sea Poneglyph",
        "Treasure Poneglyph",
      ],
      answer: "Rio Poneglyph",
    },
    {
      question:
        "Who was the original owner of the sword Enma before Zoro received it?",
      choices: ["Kozuki Oden", "Shimotsuki Ryuma", "Kawamatsu", "Kin'emon"],
      answer: "Kozuki Oden",
    },
    {
      question:
        "In the Thriller Bark arc, which shadow did Luffy receive that gave him a temporary power-up?",
      choices: ["Ryuma’s", "Oars’", "Hundred Pirates’", "Captain John’s"],
      answer: "Hundred Pirates’",
    },
  ];

  let currentQues = 0;
  let score = 0;
  let highscore = parseInt(localStorage.getItem("highscore")) || 0;

  strtBtn.addEventListener("click", startQuiz); //here we needed to pass a callback or an arrow fxn but see startquiz is a fxn in itself so we can just pass it here

  function startQuiz() {
    quesBox.classList.remove("hidden");
    strtBtn.classList.add("hidden");
    resultBox.classList.add("hidden");
    renderQuiz();
  }

  nextBtn.addEventListener("click", () => {
    currentQues++;
    if (currentQues < questions.length) {
      renderQuiz();
    } else {
      showScore();
    }
  });
  function renderQuiz() {
    nextBtn.classList.add("hidden");
    displayChoices.textContent = "";
    displayQues.textContent = "";
    displayQues.textContent = questions[currentQues].question;
    questions[currentQues].choices.forEach((choice) => {
      const li = document.createElement("li");
      li.textContent = choice;
      li.addEventListener("click", (e) => countScore(e, choice));
      displayChoices.appendChild(li);
    });
  }
  function countScore(e, choice) {
    let correctAnswer = questions[currentQues].answer;
    if (choice === correctAnswer) {
      score++;
      e.target.classList.add("right");
    } else {
      e.target.classList.add("wrong");
    }
    //gpt's help start
    const allChoices = displayChoices.querySelectorAll("li");
    allChoices.forEach((item) => {
      item.style.pointerEvents = "none"; // makes them unclickable
      item.style.opacity = "0.6"; // optional visual effect
    });
    //gpt's help over
    nextBtn.classList.remove("hidden");
  }

  function showScore() {
    if (score > highscore) {
      highscore = score;
      saveHighScore();
    }
    quesBox.classList.add("hidden");
    nextBtn.classList.add("hidden");
    resultBox.classList.remove("hidden");
    displayScore.textContent = `${score} out of ${questions.length}`;
    displayHighScore.textContent = `Your highest score : ${highscore}`;
  }

  function saveHighScore() {
    localStorage.setItem("highscore", highscore);
  }
  restrtBtn.addEventListener("click", () => {
    currentQues = 0;
    score = 0;
    startQuiz();
  });
});
