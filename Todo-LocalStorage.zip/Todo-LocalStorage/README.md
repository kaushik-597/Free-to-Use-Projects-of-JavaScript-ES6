# To-Do List Web App

A simple and responsive **To-Do List** application built using **HTML, CSS, and JavaScript**.  
It allows users to add, delete, and mark tasks as complete, while storing everything in the browser’s **localStorage** for persistence.

---

## 🚀 Features
- Add new tasks
- Mark tasks as complete/incomplete
- Delete tasks
- Tasks are saved in **localStorage** (they stay even after page reload)
- Clean, dark-themed UI

---

## 🛠️ Tech Stack
- **HTML5**
- **CSS3**
- **JavaScript (ES6)**

---

## 📂 Project Structure
```
├── index.html   # Main HTML file
├── styles.css   # Styling (Dark Theme)
└── script.js    # App logic
```

---

## ⚡ Getting Started
1. Clone this repository:
   ```bash
   git clone https://github.com/<your-username>/todo-list-app.git
   ```
2. Open `index.html` in your browser.

That’s it! ✅

---

## 📸 Preview
*(Add a screenshot or GIF of your app here if you want)*

---

## 📜 License
This project is **free to use**.  
Feel free to fork it, modify it, and use it in your own projects.

---
