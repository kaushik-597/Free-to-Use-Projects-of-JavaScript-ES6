document.addEventListener("DOMContentLoaded", () => {
  const todoList = document.querySelector("#todo-list"); //ul in html
  const taskInput = document.querySelector("#todo-input"); //input tag in html
  const inputBtn = document.querySelector("#add-task-btn"); //add task button in html

  //creating and adding task to list by "clicking" the add task button
  let tasks = JSON.parse(localStorage.getItem("tasks")) || []; // here on execution the engine will check if any item named "tasks" exists in localStorage and put it into array or if it doenst exist just assign an empty array to tasks
  //also since in local storage the the tasks are stored as an string and their actual datatype is array so we need to use JSON api method i.e. parse() which converts string to original datatype
  tasks.forEach((task) => {
    renderTask(task); //for each item in tasks array this function is to be called
  });

  inputBtn.addEventListener("click", () => {
    let taskDescription = taskInput.value.trim(); //trim() removes extra spaces in the end and start
    if (taskDescription === "") return; //if the input is empty then return nothing
    const newTask = {
      id: Date.now(), //1 out of many ways of getting a random number but its default purpose is to get ms passed from jan 1970
      action: taskDescription,
      completionStatus: false, //by default false cuz task is just defined
    };
    tasks.push(newTask); //add it into a storage i.e. array
    storeTasks();
    renderTask(newTask);
    taskInput.value = ""; //after creating task and adding it into array, then input bar is cleared
  });

  //now we gonna make a function that will make the created and stored task(in array), become visible on todo list
  function renderTask(task) {
    console.log(task);
    const li = document.createElement("li");
    li.setAttribute("data-id", task.id);
    if (task.completionStatus) li.classList.add("completed");
    li.innerHTML = `<span>${task.action}</span><button>Delete</button>`;

    li.addEventListener("click", (e) => {
      if (e.target.tagName === "BUTTON") {
        return;
      }
      task.completionStatus = !task.completionStatus;
      li.classList.toggle("completed");
      storeTasks();
    });
    li.querySelector("button").addEventListener("click", (e) => {
      e.stopPropagation(); //prevent toggle from firing
      tasks = tasks.filter((t) => t.id !== task.id);
      li.remove();
      storeTasks();
    });
    todoList.appendChild(li);
  }
  //now we need to store the array into a local storage and its ez cuz browser provides us a simple way to do so
  function storeTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks)); //here localstorage takes two args as name with which its gonna be stored in local storage and value with which its defined in the file
    //also localStorage doesnt take value as any complex datatype rather it must be a string so we need to convert our array into a string using JSON api method i.e. stringify
  }
}); //wrapped all of the script into an event listener so that nothing works until the server is loaded
